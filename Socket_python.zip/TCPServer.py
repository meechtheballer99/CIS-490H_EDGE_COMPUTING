# echo server.py

#import socket
from socket import *
import time

HOST = "127.0.0.1"
PORT = 3321

socketServer = socket(AF_INET, SOCK_STREAM)
socketServer.bind((HOST,PORT))
socketServer.listen()

while True:
    connThread, address = socketServer.accept()
    with connThread:
        print(f"Connected by {address}")
        while True:
            data = connThread.recv(1024)
            print(f"Data Received: {data}")
            if not data:
                connThread.close()
                break
            connThread.sendall(data.upper())

