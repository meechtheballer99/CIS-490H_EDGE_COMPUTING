from socket import *
import time

HOST = "127.0.0.1"
PORT = 3322

socketClient = socket(AF_INET, SOCK_DGRAM)
socketClient.connect((HOST,PORT))

socketClient.sendall(b"hello world")
data = socketClient.recv(1024)

#time.sleep(10)
#socketClient.sendall(b"Bye")

print(f"Received {data}")

socketClient.close()

