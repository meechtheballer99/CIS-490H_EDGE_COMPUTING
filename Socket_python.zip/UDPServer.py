# echo server.py

#import socket
from socket import *
import time

HOST = "127.0.0.1"
PORT = 3322

socketServer = socket(AF_INET, SOCK_DGRAM)
socketServer.bind((HOST,PORT))

while True:
    data, address = socketServer.recvfrom(1024)
    print(f"Received {data} from {address}")
    response = data.upper()
    #response = "hello world".encode()
    socketServer.sendto(response, address)

